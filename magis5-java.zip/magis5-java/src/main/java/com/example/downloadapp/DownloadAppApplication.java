package com.example.downloadapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DownloadAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(DownloadAppApplication.class, args);
    }
}
