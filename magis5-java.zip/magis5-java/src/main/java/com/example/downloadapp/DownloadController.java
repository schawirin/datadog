package com.example.downloadapp.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/")
public class DownloadController {

    private static final Logger logger = LogManager.getLogger(DownloadController.class);

    private int successCount = 0;
    private int failedCount = 0;
    private int waitingCount = 0;

    @GetMapping
    public String home(Model model) {
        model.addAttribute("successCount", successCount);
        model.addAttribute("failedCount", failedCount);
        model.addAttribute("waitingCount", waitingCount);
        return "index";
    }

    @GetMapping("/download")
    public String download(RedirectAttributes redirectAttributes) {
        waitingCount++;
        try {
            // Simule o download do arquivo aqui
            // Substitua pela URL do arquivo .zip no Google Storage
            String fileUrl = "https://storage.googleapis.com/bucket_name/file.zip";
            redirectAttributes.addAttribute("fileUrl", fileUrl);
            successCount++;
            logger.info("Download successful.");
            return "redirect:" + fileUrl;
        } catch (Exception e) {
            failedCount++;
            logger.error("Failed to download file.", e);
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to download file.");
            return "redirect:/";
        }
    }
}
