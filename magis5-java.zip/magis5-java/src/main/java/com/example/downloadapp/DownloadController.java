package com.example.downloadapp.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

@Controller
@RequestMapping("/")
public class DownloadController {

    private static final Logger logger = LogManager.getLogger(DownloadController.class);

    private int successCount = 0;
    private int failedCount = 0;
    private int waitingCount = 0;

    @GetMapping
    public String home(Model model) {
        logger.info("Acessando a página inicial");
        model.addAttribute("successCount", successCount);
        model.addAttribute("failedCount", failedCount);
        model.addAttribute("waitingCount", waitingCount);
        return "index";
    }

    @GetMapping("/download")
    public ResponseEntity<InputStreamResource> download() {
        waitingCount++;
        logger.info("Iniciando download do arquivo. Estado: waitingCount=" + waitingCount);

        String fileUrl = "https://storage.googleapis.com/bucket_name/file.zip";
        RestTemplate restTemplate = new RestTemplate();

        try {
            byte[] fileBytes = restTemplate.getForObject(fileUrl, byte[].class);
            if (fileBytes != null) {
                InputStream inputStream = new ByteArrayInputStream(fileBytes);
                InputStreamResource resource = new InputStreamResource(inputStream);

                HttpHeaders headers = new HttpHeaders();
                headers.add("Content-Disposition", "attachment; filename=file.zip");

                successCount++;
                logger.info("Download bem-sucedido. Estado: successCount=" + successCount);

                return ResponseEntity.ok()
                        .headers(headers)
                        .contentLength(fileBytes.length)
                        .body(resource);
            } else {
                throw new IOException("File is empty");
            }
        } catch (Exception e) {
            failedCount++;
            logger.error("Falha no download do arquivo. Estado: failedCount=" + failedCount, e);
            return ResponseEntity.status(500).build();
        }
    }
}
