package com.example.downloadapp.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/")
public class DownloadController {

    private static final Logger logger = LogManager.getLogger(DownloadController.class);

    private int successCount = 0;
    private int failedCount = 0;
    private int waitingCount = 0;

    @GetMapping
    public String home(Model model) {
        logger.info("Acessando a página inicial");
        model.addAttribute("successCount", successCount);
        model.addAttribute("failedCount", failedCount);
        model.addAttribute("waitingCount", waitingCount);
        return "index";
    }

    @GetMapping("/download")
    public String download(RedirectAttributes redirectAttributes) {
        waitingCount++;
        logger.info("Iniciando download do arquivo. Estado: waitingCount=" + waitingCount);

        try {
            // URL correta para o arquivo no Google Cloud Storage
            String fileUrl = "https://storage.googleapis.com/magis5-sandbox/teste.zip";
            redirectAttributes.addAttribute("fileUrl", fileUrl);
            successCount++;
            logger.info("Redirecionando para o URL do arquivo. Estado: successCount=" + successCount);
            return "redirect:" + fileUrl;
        } catch (Exception e) {
            failedCount++;
            logger.error("Falha no download do arquivo. Estado: failedCount=" + failedCount, e);
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to download file.");
            return "redirect:/";
        }
    }
}
